import opengeode_io_py_mesh as mesh_io
import opengeode_io_py_model as model_io


mesh_io.initialize_mesh_io()
model_io.initialize_model_io()

protocols = []